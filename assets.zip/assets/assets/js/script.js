document.addEventListener('keydown', function(event) {
    if (event.code === 'Space') {
        event.preventDefault();
        document.querySelector('.mario').classList.add('jump');
        setTimeout(() => {
            document.querySelector('.mario').classList.remove('jump');
        }, 500);
    }
});

const scoreElement = document.getElementById('score');
let score = 0;

const scoreloop = setInterval(() => {
    score++;
    scoreElement.textContent = score;
}, 1000);

const loop = setInterval(() => {

    console.log('loop');

    const pipe = document.querySelector('.pipe');
    const mario = document.querySelector('.mario');
    const pipePosition = pipe.offsetLeft;
    const marioPosition = +window.getComputedStyle(mario).bottom.replace('px', '');
 
    console.log(pipePosition);

    if (pipePosition <= 51 && pipePosition > 0 && marioPosition < 40) {
        pipe.style.animation = 'none';
        pipe.style.left = `${pipePosition}px`;
        mario.style.animation = 'none';
        mario.style.bottom = `${marioPosition}px`;


        mario.src = './assets/images/game-over.png';
        mario.style.width = '35px';
        mario.style.marginLeft = '-28px';

      

    }
}, 10);
